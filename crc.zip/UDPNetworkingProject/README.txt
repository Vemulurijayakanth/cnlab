
UDP Java Networking Project
===========================

This project demonstrates Java UDP-based implementations of:
1. CRC Error Detection
2. Bit Stuffing and Unstuffing
3. Byte Stuffing and De-Stuffing

Structure:
- CRC/
  - CRC_UDPSender.java
  - CRC_UDPReceiver.java

To Run:
=======
1. Compile both sender and receiver files:
   javac CRC_UDPSender.java
   javac CRC_UDPReceiver.java

2. First run the receiver:
   java CRC_UDPReceiver

3. Then run the sender:
   java CRC_UDPSender

You should see the CRC verification result in the receiver's console.
