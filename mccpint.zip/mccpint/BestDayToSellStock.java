import java.util.Scanner;

public class BestDayToSellStock {
    
    // Function to calculate the maximum profit
    public static int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE; // Track minimum price seen so far
        int maxProfit = 0; // Track maximum profit
        
        for (int price : prices) {
            if (price < minPrice) {
                minPrice = price; // Update minPrice if current price is lower
            } else {
                maxProfit = Math.max(maxProfit, price - minPrice); // Update maxProfit
            }
        }
        
        return maxProfit;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Taking dynamic input for number of days
        System.out.print("Enter the number of days: ");
        int n = sc.nextInt();
        
        int[] prices = new int[n];
        
        // Taking dynamic input for stock prices
        System.out.println("Enter the stock prices for each day:");
        for (int i = 0; i < n; i++) {
            prices[i] = sc.nextInt();
        }
        
        // Calculating the maximum profit
        int profit = maxProfit(prices);
        
        // Output the maximum profit
        System.out.println("Maximum profit: " + profit);
        
        sc.close();
    }
}
