import java.util.Scanner;

public class ArrayCeilFloor {
    
    // Function to find Ceil and Floor closest to x
    public static void findCeilFloor(int[] arr, int x) {
        int ceil = Integer.MAX_VALUE;  // Initialize Ceil as maximum value
        int floor = Integer.MIN_VALUE; // Initialize Floor as minimum value

        // Iterate through the array to find Ceil and Floor
        for (int num : arr) {
            if (num >= x && num < ceil) {
                ceil = num;
            }
            if (num <= x && num > floor) {
                floor = num;
            }
        }

        if (ceil == Integer.MAX_VALUE) {
            System.out.println("No Ceil found.");
        } else {
            System.out.println("Ceil closest to " + x + ": " + ceil);
        }

        if (floor == Integer.MIN_VALUE) {
            System.out.println("No Floor found.");
        } else {
            System.out.println("Floor closest to " + x + ": " + floor);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the number of elements in the array: ");
        int n = sc.nextInt();
        
        // Input array elements
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        // Input the value of x
        System.out.print("Enter the value of x: ");
        int x = sc.nextInt();

        // Call function to find Ceil and Floor closest to x
        findCeilFloor(arr, x);

        sc.close();
    }
}
