import java.util.Scanner;

class Node {
    int data;
    Node left, right;
    
    public Node(int data) {
        this.data = data;
        left = right = null;
    }
}

public class HalfNodesInBST {
    
    // Function to insert a node in the BST
    public static Node insert(Node root, int data) {
        if (root == null) {
            return new Node(data);
        }
        
        if (data < root.data) {
            root.left = insert(root.left, data);
        } else if (data > root.data) {
            root.right = insert(root.right, data);
        }
        
        return root;
    }
    
    // Function to count half nodes
    public static int countHalfNodes(Node root) {
        if (root == null) {
            return 0;
        }
        
        // If the node has one child, it's a half node
        int count = 0;
        if ((root.left == null && root.right != null) || (root.left != null && root.right == null)) {
            count = 1;
        }
        
        // Recursively count half nodes in left and right subtrees
        count += countHalfNodes(root.left);
        count += countHalfNodes(root.right);
        
        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Taking dynamic input for the number of nodes
        System.out.print("Enter the number of nodes in the BST: ");
        int n = sc.nextInt();
        
        Node root = null;
        
        // Taking dynamic input for node values and inserting them into the BST
        System.out.println("Enter the data for each node:");
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            root = insert(root, data);
        }
        
        // Counting half nodes
        int halfNodes = countHalfNodes(root);
        
        // Output the number of half nodes
        System.out.println("Number of half nodes: " + halfNodes);
        
        sc.close();
    }
}
