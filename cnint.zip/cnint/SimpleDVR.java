import java.util.*;

public class SimpleDVR {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input number of nodes
        System.out.print("Enter the number of nodes: ");
        int numNodes = sc.nextInt();

        int[][] dmart = new int[numNodes][numNodes]; // Distance matrix

        // Input distance matrix
        System.out.println("Enter the distance matrix:");
        for (int i = 0; i < numNodes; i++) {
            for (int j = 0; j < numNodes; j++) {
                dmart[i][j] = sc.nextInt();
            }
        }

        int[][] rt = new int[numNodes][numNodes]; // Routing table
        int[][] nh = new int[numNodes][numNodes]; // Next hop table

        // Initialize routing and next hop tables
        for (int i = 0; i < numNodes; i++) {
            for (int j = 0; j < numNodes; j++) {
                if (dmart[i][j] == 0) {
                    if (i == j) {
                        rt[i][j] = 0;
                    } else {
                        rt[i][j] = 999; // Infinite cost for no direct path
                    }
                    nh[i][j] = -1; // No next hop
                } else {
                    rt[i][j] = dmart[i][j];
                    nh[i][j] = j;
                }
            }
        }

        // DVR algorithm (Bellman-Ford like update)
        boolean updated;
        do {
            updated = false;
            for (int i = 0; i < numNodes; i++) {
                for (int j = 0; j < numNodes; j++) {
                    if (i != j) {
                        for (int k = 0; k < numNodes; k++) {
                            if (rt[i][k] + rt[k][j] < rt[i][j]) {
                                rt[i][j] = rt[i][k] + rt[k][j];
                                nh[i][j] = nh[i][k];
                                updated = true;
                            }
                        }
                    }
                }
            }
        } while (updated);

        // Display routing tables
        System.out.println("\nRouting tables for each node:");
        for (int i = 0; i < numNodes; i++) {
            System.out.println("Router " + i + "'s Routing Table:");
            for (int j = 0; j < numNodes; j++) {
                if (rt[i][j] == 999) {
                    System.out.println("Destination " + j + " | Cost: ∞ | Next Hop: None");
                } else {
                    System.out.println("Destination " + j + " | Cost: " + rt[i][j] + " | Next Hop: " + nh[i][j]);
                }
            }
            System.out.println();
        }

        sc.close();
    }
}
