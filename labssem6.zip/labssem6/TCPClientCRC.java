import java.io.*;
import java.net.*;
import java.util.Scanner;
public class TCPClientCRC {
    private static final String GENERATOR = "100000111";
    public static void main(String[] args) {
        String serverIP = "127.0.0.1";
        int port = 12345;
        Scanner scanner = new Scanner(System.in);
        try (Socket socket = new Socket(serverIP, port);
             BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter output = new PrintWriter(socket.getOutputStream(), true)
        ) {
            System.out.println("Server: " + input.readLine());
            System.out.print("Enter message (in binary): ");
            String message = scanner.nextLine();
            String messageWithZeros = message + "00000000";
            String crc = calculateCRC(messageWithZeros);
            String codeword = message + crc;
            System.out.println("Sending codeword: " + codeword);
            output.println(codeword);
            System.out.println("Server: " + input.readLine());
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
        scanner.close();
    }
    private static String calculateCRC(String data) {
        char[] bits = data.toCharArray();
        int dataLength = bits.length;
        int generatorLength = GENERATOR.length();
        for (int i = 0; i <= dataLength - generatorLength; i++) {
            if (bits[i] == '1') {
                for (int j = 0; j < generatorLength; j++) {
                    if (bits[i + j] == GENERATOR.charAt(j)) {
                        bits[i + j] = '0';
                    } else {
                        bits[i + j] = '1';
                    }
                }
            }
        }
        int crcStart = dataLength - generatorLength + 1;
        StringBuilder crc = new StringBuilder();
        for (int i = crcStart; i < dataLength; i++) {
            crc.append(bits[i]);
        }
        return crc.toString();
    }
}
