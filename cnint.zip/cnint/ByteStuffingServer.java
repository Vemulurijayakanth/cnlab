import java.io.*;
import java.net.*;

public class ByteStuffingServer {
    public static void main(String[] args) {
        String flag = "01111110"; // Frame flag
        String esc = "01111101";  // Escape sequence

        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is waiting for a connection...");
            Socket socket = serverSocket.accept(); // Wait for client connection

            InputStream inStream = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));

            String receivedData = reader.readLine();
            System.out.println("Received (Stuffed Data): " + receivedData);

            // Perform Byte DeStuffing
            StringBuilder originalData = new StringBuilder();
            int i = 0;
            while (i < receivedData.length()) {
                if (receivedData.charAt(i) == esc.charAt(0) && i + 8 <= receivedData.length()) {
                    i += 8; // Skip the escape byte
                }
                
                // Adjust substring length if remaining characters are less than 8
                int endIndex = Math.min(i + 8, receivedData.length());
                originalData.append(receivedData.substring(i, endIndex));
                i = endIndex; // Move i to the next block
            }

            // Display the original data after de-stuffing
            System.out.println("Received (Original Data): " + originalData.toString());

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
