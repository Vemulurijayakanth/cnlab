import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class CRCUDPServer {
    public static void main(String[] args) {
        try (DatagramSocket serverSocket = new DatagramSocket(9876)) {
            byte[] buffer = new byte[1024];
            System.out.println(" CRC UDP Server is running...");

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                serverSocket.receive(receivePacket);

                String receivedCodeword = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Received Codeword: " + receivedCodeword);

                boolean isValid = CRCUtil.verify(receivedCodeword);
                String response = isValid ? "No error detected " : "Error detected ";

                // Send response to client
                byte[] responseBytes = response.getBytes();
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                DatagramPacket sendPacket = new DatagramPacket(responseBytes, responseBytes.length, clientAddress, clientPort);
                serverSocket.send(sendPacket);

                // Optional: Exit server on specific message
                if (receivedCodeword.equalsIgnoreCase("quit")) {
                    System.out.println("Server shutting down...");
                    break;
                }
            }

        } catch (Exception e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}
