import java.util.*;

public class DecreasingPairs {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();
        
        int[] arr = new int[n];
        System.out.println("Enter elements:");
        for(int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int count = 0;
        System.out.println("Output pairs (a > b):");
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                if (arr[i] > arr[j]) {
                    System.out.print("(" + arr[i] + "," + arr[j] + ") ");
                    count++;
                }
            }
        }

        System.out.println("\nTotal pairs: " + count);
        sc.close();
    }
}
