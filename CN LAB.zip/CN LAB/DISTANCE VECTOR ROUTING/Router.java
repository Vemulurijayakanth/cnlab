import java.util.*;

class Router {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of nodes:");
        int n = sc.nextInt();

        int arr[][] = new int[n][n];
        System.out.println("Enter the distance between the nodes (use 999 for no path):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                arr[i][j] = sc.nextInt();
            }
        }

        distanceVector(arr, n);
        sc.close();
    }

    public static void distanceVector(int[][] a, int n) {
        int[][] next = new int[n][n];

        // Initialize next hop table
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j] != 0 && a[i][j] != 999) {
                    next[i][j] = j;
                } else {
                    next[i][j] = -1;
                }
            }
        }

        // Apply Distance Vector logic (similar to Floyd-Warshall)
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (a[i][k] != 999 && a[k][j] != 999 && a[i][j] > a[i][k] + a[k][j]) {
                        a[i][j] = a[i][k] + a[k][j];
                        next[i][j] = next[i][k];
                    }
                }
            }
        }

        // Print routing tables
        for (int i = 0; i < n; i++) {
            System.out.println("\nRouting table for node " + i + ":");
            System.out.println("Destination \t NextHop \t Cost");
            for (int j = 0; j < n; j++) {
                if (i != j) {
                    System.out.println(j + "\t\t\t" + next[i][j] + "\t\t\t" + a[i][j]);
                }
            }
        }
    }
}
