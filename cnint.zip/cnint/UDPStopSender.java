import java.net.*;
import java.util.Scanner;

public class UDPStopSender {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of frames: ");
        int totalFrames = sc.nextInt();

        for (int i = 0; i < totalFrames; i++) {
            boolean ackReceived = false;

            while (!ackReceived) {
                // Send frame
                String frame = String.valueOf(i);
                byte[] sendBuffer = frame.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, ip, 9876);
                socket.send(sendPacket);
                System.out.println("Sent Frame: " + i);

                // Set timeout to wait for ACK
                try {
                    socket.setSoTimeout(2000); // 2 seconds
                    byte[] receiveBuffer = new byte[1024];
                    DatagramPacket ackPacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                    socket.receive(ackPacket);

                    String ack = new String(ackPacket.getData(), 0, ackPacket.getLength()).trim();
                    if (ack.equals("ACK" + i)) {
                        System.out.println("Received: " + ack);
                        ackReceived = true;
                    }
                } catch (SocketTimeoutException e) {
                    System.out.println("Timeout! Resending Frame " + i);
                }
            }
        }

        socket.close();
        sc.close();
    }
}
