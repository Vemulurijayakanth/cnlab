import java.util.Scanner;

public class EquilibriumIndex {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements in the array: ");
        int n = sc.nextInt();
        int[] arr = new int[n];

        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int totalSum = 0;
        for (int i = 0; i < n; i++) {
            totalSum += arr[i];
        }

        int leftSum = 0;
        boolean foundEquilibrium = false;
        for (int i = 0; i < n; i++) {
            totalSum -= arr[i];  // Subtract current element from totalSum to get the right sum

            if (leftSum == totalSum) {
                System.out.println("Equilibrium index: " + i);
                foundEquilibrium = true;
                break;
            }

            leftSum += arr[i];  // Add current element to left sum
        }

        if (!foundEquilibrium) {
            System.out.println("No equilibrium index found.");
        }
    }
}
