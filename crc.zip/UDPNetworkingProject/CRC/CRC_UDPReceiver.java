
import java.net.DatagramSocket;
import java.net.DatagramPacket;

public class CRC_UDPReceiver {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket(2000);
        byte[] buf = new byte[1024];
        DatagramPacket dp = new DatagramPacket(buf, buf.length);
        ds.receive(dp);

        String receivedData = new String(dp.getData(), 0, dp.getLength());
        String g = "100000111";
        boolean isValid = checkCRC(receivedData, g);

        if (isValid) {
            System.out.println("No errors");
        } else {
            System.out.println("Errors detected");
        }
        ds.close();
    }

    private static boolean checkCRC(String data, String g) {
        int dl = data.length();
        int gl = g.length();
        char[] dArr = data.toCharArray();
        char[] gArr = g.toCharArray();
        for (int i = 0; i <= dl - gl; i++) {
            if (dArr[i] == '1') {
                for (int j = 0; j < gl; j++) {
                    dArr[i + j] = (dArr[i + j] == gArr[j]) ? '0' : '1';
                }
            }
        }
        for (int i = dl - gl + 1; i < dl; i++) {
            if (dArr[i] != '0') return false;
        }
        return true;
    }
}
