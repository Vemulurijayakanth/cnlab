import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 8080);  // Replace with actual server IP if remote
        System.out.println("Connected to server.");

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        String input;
        while (true) {
            System.out.print("Enter shell command (or 'exit' to quit): ");
            input = userInput.readLine();
            out.println(input);

            if (input.equalsIgnoreCase("exit")) {
                System.out.println(in.readLine());
                break;
            }

            String responseLine;
            System.out.println("\n--- Output ---");
            while ((responseLine = in.readLine()) != null) {
                if (responseLine.equals("__END__")) break;  // End of output marker
                System.out.println(responseLine);
            }
            System.out.println("--------------\n");
        }

        socket.close();
    }
}
