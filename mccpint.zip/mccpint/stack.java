import java.util.*;

public class Main {
    static class StackWithMin {
        Stack<Integer> stack = new Stack<>();
        Stack<Integer> minStack = new Stack<>();
        
        void push(int value) {
            stack.push(value);
            if (minStack.isEmpty() || value <= minStack.peek()) {
                minStack.push(value);
            }
        }
        
        int pop() {
            if (stack.isEmpty()) return Integer.MIN_VALUE;
            int value = stack.pop();
            if (value == minStack.peek()) {
                minStack.pop();
            }
            return value;
        }
        
        int getMin() {
            if (minStack.isEmpty()) return Integer.MIN_VALUE;
            return minStack.peek();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StackWithMin stack = new StackWithMin();
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            int value = sc.nextInt();
            stack.push(value);
        }
        System.out.println("Minimum element: " + stack.getMin());
    }
}
