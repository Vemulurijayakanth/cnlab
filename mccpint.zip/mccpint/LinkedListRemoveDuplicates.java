import java.util.HashSet;
import java.util.Scanner;

class Node {
    int data;
    Node next;

    // Constructor to create a new node
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    // Insert node at the end
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Remove duplicates from the linked list
    public void removeDuplicates() {
        if (head == null) {
            return;
        }

        HashSet<Integer> seen = new HashSet<>();
        Node current = head;
        Node previous = null;

        while (current != null) {
            if (seen.contains(current.data)) {
                // Remove the duplicate node
                previous.next = current.next;
            } else {
                // Add to the set and move previous pointer
                seen.add(current.data);
                previous = current;
            }
            current = current.next;
        }
    }

    // Display the linked list
    public void display() {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node temp = head;
        System.out.print("Linked List: ");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class LinkedListRemoveDuplicates {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList list = new LinkedList();
        
        // Dynamic input: Enter the number of elements in the linked list
        System.out.print("Enter number of elements in the linked list: ");
        int n = sc.nextInt();
        
        System.out.println("Enter the elements of the linked list:");
        // Dynamic input: Insert elements into the linked list
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            list.insert(data);
        }

        // Display the linked list before removing duplicates
        list.display();

        // Remove duplicates
        list.removeDuplicates();

        // Display the modified linked list
        System.out.println("Linked list after removing duplicates:");
        list.display();

        sc.close();
    }
}
