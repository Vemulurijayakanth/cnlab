import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class SenderCRC {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String g = "100000111";

        System.out.print("Enter the data to be sent: ");
        String data = sc.nextLine();

        String pdata = data + "00000000"; // append zeroes
        String crc = calculateCRC(pdata, g);
        String tdata = data + crc;

        System.out.println("CRC: " + crc);
        System.out.println("Transmitted data: " + tdata);

        DatagramSocket socket = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        byte[] sendData = tdata.getBytes();

        DatagramPacket packet = new DatagramPacket(sendData, sendData.length, ip, 9876);
        socket.send(packet);
        System.out.println("Data sent to receiver via UDP.");
        socket.close();
        sc.close();
    }

    private static String calculateCRC(String data, String g) {
        int dl = data.length();
        int gl = g.length();
        char[] dArr = data.toCharArray();
        char[] gArr = g.toCharArray();

        for (int i = 0; i <= dl - gl; i++) {
            if (dArr[i] == '1') {
                for (int j = 0; j < gl; j++) {
                    dArr[i + j] = (dArr[i + j] == gArr[j]) ? '0' : '1';
                }
            }
        }

        StringBuilder remainder = new StringBuilder();
        for (int i = dl - gl + 1; i < dl; i++) {
            remainder.append(dArr[i]);
        }

        return remainder.toString();
    }
}
