import java.util.*;

public class Main {
    static void dfs(int node, boolean[] visited, int[][] adj) {
        visited[node] = true;
        System.out.print(node + " ");
        for (int i = 0; i < adj.length; i++) {
            if (adj[node][i] == 1 && !visited[i]) {
                dfs(i, visited, adj);
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int[][] adj = new int[n][n];

        for (int i = 0; i < m; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adj[u][v] = 1;
            adj[v][u] = 1;
        }

        boolean[] visited = new boolean[n];
        dfs(0, visited, adj);
    }
}
