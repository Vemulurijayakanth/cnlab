import java.util.Scanner;

public class LongestIncreasingSubsequence {
    // Method to find the longest increasing subsequence
    public static int findLIS(int[] arr) {
        int n = arr.length;
        int[] dp = new int[n];

        // Initialize dp array, where each element is at least a subsequence of length 1
        for (int i = 0; i < n; i++) {
            dp[i] = 1;
        }

        // Fill dp array using dynamic programming
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j]) {
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
        }

        // Find the maximum value in dp array which is the length of the LIS
        int lis = 0;
        for (int i = 0; i < n; i++) {
            lis = Math.max(lis, dp[i]);
        }

        return lis;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take dynamic input for the array
        System.out.println("Enter the number of elements in the array:");
        int n = scanner.nextInt();
        
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Call the method to find LIS
        int lis = findLIS(arr);

        // Print the result
        System.out.println("The length of the Longest Increasing Subsequence is: " + lis);
        scanner.close();
    }
}
