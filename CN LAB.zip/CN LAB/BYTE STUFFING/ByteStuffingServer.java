import java.io.*;
import java.net.*;

public class ByteStuffingServer {
    private static final String FLAG = "01111110";
    private static final String ESCAPE = "01111101";

    public static void main(String[] args) {
        int port = 5000;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started. Waiting for connection...");

            Socket socket = serverSocket.accept();
            System.out.println("Client connected!");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String stuffedData = in.readLine();
            System.out.println("Received stuffed data: " + stuffedData);

            String unstuffed = unstuffData(stuffedData);
            System.out.println("Unstuffed Data: " + unstuffed);

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String unstuffData(String stuffedData) {
        String data = stuffedData.substring(FLAG.length(), stuffedData.length() - FLAG.length());
        StringBuilder unstuffedData = new StringBuilder();

        for (int i = 0; i < data.length(); i += 8) {
            String byteChunk = data.substring(i, Math.min(i + 8, data.length()));
            if (byteChunk.equals(ESCAPE)) {
                i += 8;
                byteChunk = data.substring(i, Math.min(i + 8, data.length()));
            }
            unstuffedData.append(byteChunk);
        }

        return unstuffedData.toString();
    }
}
