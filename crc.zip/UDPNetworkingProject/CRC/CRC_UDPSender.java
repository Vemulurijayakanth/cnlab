
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.util.Scanner;

public class CRC_UDPSender {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String g = "100000111";
        System.out.print("Enter the data to be sent: ");
        String data = sc.nextLine();
        String pdata = data + "00000000";
        String crc = calculateCRC(pdata, g);
        String tdata = data + crc;
        System.out.println("CRC: " + crc);
        System.out.println("Transmitted data: " + tdata);

        DatagramSocket ds = new DatagramSocket();
        DatagramPacket dp = new DatagramPacket(tdata.getBytes(), tdata.length(), java.net.InetAddress.getLocalHost(), 2000);
        ds.send(dp);
        ds.close();
        sc.close();
    }

    private static String calculateCRC(String data, String g) {
        int dl = data.length();
        int gl = g.length();
        char[] dArr = data.toCharArray();
        char[] garr = g.toCharArray();
        for (int i = 0; i <= dl - gl; i++) {
            if (dArr[i] == '1') {
                for (int j = 0; j < gl; j++) {
                    dArr[i + j] = (dArr[i + j] == garr[j]) ? '0' : '1';
                }
            }
        }
        StringBuilder remainder = new StringBuilder();
        for (int i = dl - gl + 1; i < dl; i++) {
            remainder.append(dArr[i]);
        }
        return remainder.toString();
    }
}
