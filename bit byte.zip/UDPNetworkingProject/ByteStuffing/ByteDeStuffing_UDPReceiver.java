import java.net.*;

public class ByteDeStuffing_UDPReceiver {
    public static void main(String[] args) throws Exception {
        String flag = "01111110";
        String esc = "01111101";
        DatagramSocket socket = new DatagramSocket(9878);
        byte[] buffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        System.out.println("Waiting for stuffed data...");
        socket.receive(packet);
        String td = new String(packet.getData(), 0, packet.getLength());

        if (td.startsWith(flag) && td.endsWith(flag)) {
            String ro = td.substring(flag.length(), td.length() - flag.length());
            StringBuilder od = new StringBuilder();
            for (int i = 0; i < ro.length(); i += 8) {
                String b8 = ro.substring(i, Math.min(i + 8, ro.length()));
                if (b8.equals(esc)) {
                    i += 8;
                    if (i >= ro.length()) break;
                    b8 = ro.substring(i, Math.min(i + 8, ro.length()));
                }
                od.append(b8);
            }
            System.out.println("Original Data: " + od.toString());
        } else {
            System.out.println("Invalid input");
        }
        socket.close();
    }
}