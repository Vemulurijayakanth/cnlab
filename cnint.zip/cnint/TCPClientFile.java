import java.io.*;
import java.net.*;

public class TCPClientFile {
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost", 9999);

        // Send file name
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter file name to request: ");
        String filename = br.readLine();

        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        dout.writeUTF(filename);

        // Receive file content
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
        String line;
        System.out.println("\n--- File content from server ---");
        while ((line = in.readLine()) != null) {
            System.out.println(line);
        }

        s.close();
    }
}
