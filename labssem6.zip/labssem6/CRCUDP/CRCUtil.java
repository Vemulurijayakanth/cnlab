public class CRCUtil {
    private static final String GENERATOR = "100000111";

    public static String encode(String data) {
        String appendedData = data + "0".repeat(GENERATOR.length() - 1);
        return data + calculateCRC(appendedData);
    }

    public static boolean verify(String codeword) {
        char[] bits = codeword.toCharArray();
        int generatorLength = GENERATOR.length();

        for (int i = 0; i <= bits.length - generatorLength; i++) {
            if (bits[i] == '1') {
                for (int j = 0; j < generatorLength; j++) {
                    bits[i + j] = (bits[i + j] == GENERATOR.charAt(j)) ? '0' : '1';
                }
            }
        }

        for (int i = bits.length - (generatorLength - 1); i < bits.length; i++) {
            if (bits[i] == '1') {
                return false;
            }
        }
        return true;
    }

    private static String calculateCRC(String data) {
        char[] bits = data.toCharArray();
        int generatorLength = GENERATOR.length();

        for (int i = 0; i <= bits.length - generatorLength; i++) {
            if (bits[i] == '1') {
                for (int j = 0; j < generatorLength; j++) {
                    bits[i + j] = (bits[i + j] == GENERATOR.charAt(j)) ? '0' : '1';
                }
            }
        }

        return new String(bits, bits.length - (generatorLength - 1), generatorLength - 1);
    }
}
