import java.util.Scanner;

class TernarySearch {

    // Method for ternary search
    public static int ternarySearch(int[] arr, int left, int right, int target) {
        if (right >= left) {
            // Finding two mid points
            int mid1 = left + (right - left) / 3;
            int mid2 = right - (right - left) / 3;

            // Check if target is at mid1 or mid2
            if (arr[mid1] == target) {
                return mid1;
            }
            if (arr[mid2] == target) {
                return mid2;
            }

            // Target is smaller, search left part
            if (target < arr[mid1]) {
                return ternarySearch(arr, left, mid1 - 1, target);
            }
            // Target is larger, search right part
            if (target > arr[mid2]) {
                return ternarySearch(arr, mid2 + 1, right, target);
            }

            // Target lies between mid1 and mid2, search middle part
            return ternarySearch(arr, mid1 + 1, mid2 - 1, target);
        }

        // If the target is not present
        return -1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Taking dynamic input for the array
        System.out.println("Enter the number of elements in the array:");
        int n = scanner.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter the elements of the array (in sorted order):");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Taking dynamic input for the target
        System.out.println("Enter the target value to search:");
        int target = scanner.nextInt();

        // Performing ternary search
        int result = ternarySearch(arr, 0, arr.length - 1, target);
        
        if (result == -1) {
            System.out.println("Target not found.");
        } else {
            System.out.println("Target found at index " + result);
        }

        scanner.close();
    }
}
