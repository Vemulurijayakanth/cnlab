import java.util.Scanner;

class Node {
    int data;
    Node next;

    // Constructor to create a new node
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    // Insert node at the end
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Recursive search for an element and return its index
    public int searchRecursive(Node node, int target, int index) {
        if (node == null) {
            return -1; // Element not found
        }
        if (node.data == target) {
            return index; // Return the index where the element is found
        }
        return searchRecursive(node.next, target, index + 1); // Recursive call with incremented index
    }

    // Display the linked list
    public void display() {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node temp = head;
        System.out.print("Linked List: ");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class LinkedListRecursiveSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList list = new LinkedList();
        
        System.out.print("Enter number of elements in the linked list: ");
        int n = sc.nextInt();
        
        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            list.insert(data);
        }

        // Display the linked list
        list.display();

        System.out.print("Enter value to search: ");
        int target = sc.nextInt();

        // Recursive search
        int index = list.searchRecursive(list.head, target, 0);
        if (index != -1) {
            System.out.println("Element " + target + " found at index " + index + " (Recursive search).");
        } else {
            System.out.println("Element " + target + " not found (Recursive search).");
        }

        sc.close();
    }
}
