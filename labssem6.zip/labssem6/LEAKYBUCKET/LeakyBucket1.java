import java.time.*;
import java.time.format.DateTimeFormatter;
class LeakyBucket {
    private int total = 0;
    private final int max = 50;
    private boolean doneProducing = false;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
    private String getCurrentTime() {
        return LocalTime.now().format(formatter);
    }
    public synchronized void add(int num) throws InterruptedException {
        if (num == 0) {
            System.out.println(getCurrentTime() + " | Added: 0 | Total: " + total + " | Left: " + num);
            return;
        }
        while (total >= max) wait();
        int addAmount = Math.min(num, max - total);
        total += addAmount;
        num -= addAmount;
        System.out.println(getCurrentTime() + " | Added: " + addAmount + " | Total: " + total + " | Left: " + num);
        notifyAll();
    }
    public synchronized void leak() throws InterruptedException {
        while (total == 0 && !doneProducing) wait();
        if (total > 0) {
            int leakAmount = Math.min(total, 10);
            total -= leakAmount;
            System.out.println(getCurrentTime() + " | Leaked: " + leakAmount + " | Remaining: " + total);
        }
notifyAll();
    }
    public synchronized void markDone() {
        doneProducing = true;
        notifyAll();
    }
    public synchronized boolean isEmpty() {
        return total == 0 && doneProducing;
    }
}
public class LeakyBucket1 {
    public static void main(String[] args) {
        LeakyBucket bucket = new LeakyBucket();
        int[] data = {45, 30, 20, 0, 5, 0, 5, 35, 50};
        Thread producer = new Thread(() -> {
            try {
                for (int num : data) {
                    bucket.add(num);
                    //Thread.sleep(500);  Simulate data arrival delay
                }
                bucket.markDone();
            } catch (InterruptedException ignored) {}
        });

        Thread consumer = new Thread(() -> {
            try {
                while (!bucket.isEmpty()) {
                    bucket.leak();
                    Thread.sleep(1000); 
                }
            } catch (InterruptedException ignored) {}
        });
        producer.start();
        consumer.start();
    }
}
