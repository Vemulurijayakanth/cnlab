import java.util.Scanner;

public class ProductArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter size of array:");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter elements:");
        for (int i = 0; i < n; i++) arr[i] = scanner.nextInt();

        int[] left = new int[n];
        int[] right = new int[n];
        int[] result = new int[n];

        left[0] = 1;
        for (int i = 1; i < n; i++) left[i] = left[i - 1] * arr[i - 1];

        right[n - 1] = 1;
        for (int i = n - 2; i >= 0; i--) right[i] = right[i + 1] * arr[i + 1];

        for (int i = 0; i < n; i++) result[i] = left[i] * right[i];

        System.out.println("Product array without division:");
        for (int val : result) System.out.print(val + " ");
    }
}
