import java.util.*;

public class Main {
    static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of nodes: ");
        int n = sc.nextInt();
        int[][] graph = new int[n][n];

        System.out.println("Enter the distance matrix (Enter 999 for no path between nodes):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                graph[i][j] = sc.nextInt();
            }
        }

        System.out.print("Enter the source node (0 to " + (n - 1) + "): ");
        int source = sc.nextInt();

        dijkstra(graph, source, n);

        sc.close();
    }

    static void dijkstra(int[][] graph, int src, int n) {
        int[] dist = new int[n];
        boolean[] sptSet = new boolean[n];

        Arrays.fill(dist, INF);
        Arrays.fill(sptSet, false);
        dist[src] = 0;

        for (int count = 0; count < n - 1; count++) {
            int u = minDistance(dist, sptSet, n);
            sptSet[u] = true;

            for (int v = 0; v < n; v++) {
                if (!sptSet[v] && graph[u][v] != 0 &&
                    dist[u] != INF && dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v];
                }
            }
        }

        printSolution(dist, n);
    }

    static int minDistance(int[] dist, boolean[] sptSet, int n) {
        int min = INF, min_index = -1;

        for (int v = 0; v < n; v++) {
            if (!sptSet[v] && dist[v] <= min) {
                min = dist[v];
                min_index = v;
            }
        }
        return min_index;
    }

    static void printSolution(int[] dist, int n) {
        System.out.println("Vertex \t Distance from Source");
        for (int i = 0; i < n; i++) {
            if (dist[i] == INF) {
                System.out.println(i + " \t 999");
            } else {
                System.out.println(i + " \t " + dist[i]);
            }
        }
    }
}
