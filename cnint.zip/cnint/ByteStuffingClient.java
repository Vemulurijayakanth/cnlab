import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ByteStuffingClient {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String flag = "01111110"; // Frame flag
        String esc = "01111101";  // Escape sequence

        // Setup connection to the server
        String serverAddress = "localhost"; // Server address
        int serverPort = 12345; // Port for connection
        try (Socket socket = new Socket(serverAddress, serverPort)) {
            OutputStream outStream = socket.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outStream));

            System.out.println("Enter the input: ");
            String input = sc.nextLine();
            StringBuilder td = new StringBuilder();
            td.append(flag); // Add flag at the beginning

            // Apply byte stuffing
            for (int i = 0; i < input.length(); i += 8) {
                String b8 = input.substring(i, Math.min(i + 8, input.length()));
                if (b8.equals(flag) || b8.equals(esc)) {
                    td.append(esc);
                }
                td.append(b8);
            }

            td.append(flag); // Add flag at the end

            // Send the stuffed data to the server
            writer.write(td.toString());
            writer.newLine();
            writer.flush();
            System.out.println("Transmitted: " + td.toString());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }
}
