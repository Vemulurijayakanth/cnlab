import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TCPBitClient {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the binary string: ");
        String input = sc.nextLine();
        sc.close();

        String FLAG = "01111110";
        String stuffedData = FLAG + bitStuff(input) + FLAG;

        Socket s = new Socket("localhost", 5000);
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
        out.println(stuffedData);
        System.out.println("Sent stuffed data: " + stuffedData);

        s.close();
    }

    public static String bitStuff(String data) {
        StringBuilder stuffed = new StringBuilder();
        int count = 0;
        for (int i = 0; i < data.length(); i++) {
            stuffed.append(data.charAt(i));
            if (data.charAt(i) == '1') {
                count++;
                if (count == 5) {
                    stuffed.append('0');
                    count = 0;
                }
            } else {
                count = 0;
            }
        }
        return stuffed.toString();
    }
}
