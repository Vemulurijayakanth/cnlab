import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
public class CustomUDPServer {
    public static void main(String[] args) {
        try (DatagramSocket serverSocket = new DatagramSocket(9876)) {
            byte[] buffer = new byte[1024];
            System.out.println("Custom UDP Server is active...");
            int quitCount = 0;
            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                serverSocket.receive(receivePacket);
                String clientMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Client sent: " + clientMessage);
                if (clientMessage.equalsIgnoreCase("quit")) {
                    quitCount++;
                    System.out.println("Quit count: " + quitCount);

                    if (quitCount == 2) {
                        System.out.println("Two clients have quit. Shutting down the server...");
                        break;
                    }
                } else {
                    InetAddress clientIP = receivePacket.getAddress();
                    int clientPort = receivePacket.getPort();
                    String customResponse = "Server: " + clientMessage;

                    byte[] responseData = customResponse.getBytes();
                    DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length, clientIP, clientPort);
                    serverSocket.send(responsePacket);
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred in the server: " + e.getMessage());
        }
    }
}
