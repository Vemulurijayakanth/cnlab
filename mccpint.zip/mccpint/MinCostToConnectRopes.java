import java.util.*;

public class MinCostToConnectRopes {
    public static int minCost(int[] ropes) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for (int rope : ropes) {
            minHeap.offer(rope);
        }

        int cost = 0;
        while (minHeap.size() > 1) {
            int first = minHeap.poll();
            int second = minHeap.poll();
            int sum = first + second;
            cost += sum;
            minHeap.offer(sum);
        }

        return cost;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of ropes: ");
        int n = scanner.nextInt();
        int[] ropes = new int[n];

        System.out.print("Enter rope lengths: ");
        for (int i = 0; i < n; i++) {
            ropes[i] = scanner.nextInt();
        }

        System.out.println("Minimum cost to connect all ropes: " + minCost(ropes));
    }
}
