import java.io.*;
import java.net.*;
public class BitStuffingReceiverTCPServer {
    public static void main(String[] args) {
        int port = 12345;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server listening on port " + port);
            while (true) {
                try (
                    Socket clientSocket = serverSocket.accept();
                    BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true)
                ) {
                    String stuffedBits = input.readLine();
                    System.out.println("Received Stuffed Sequence: " + stuffedBits);
                    String destuffed = destuffBits(stuffedBits);
                    output.println(destuffed);  
                    System.out.println("Destuffed Sequence Sent: " + destuffed);
                }
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    private static String destuffBits(String input) {
        StringBuilder output = new StringBuilder();
        int count = 0;
        for (int i = 8; i < input.length() - 8; i++) {
            char bit = input.charAt(i);
            output.append(bit);

            if (bit == '1') {
                count++;
                if (count == 5) {
                    i++; 
                    count = 0;
                }
            } else {
                count = 0;
            }
        }
        return output.toString();
    }
}
