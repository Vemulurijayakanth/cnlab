import java.net.*;
import java.util.Scanner;

public class UDPcmdClient {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("localhost");
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("Enter shell command (or 'exit' to quit): ");
            String command = sc.nextLine();
            byte[] sendData = command.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, 9876);
            socket.send(sendPacket);

            if (command.equalsIgnoreCase("exit")) {
                break;
            }

            byte[] receiveData = new byte[4096];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);

            String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("\n--- Output ---");
            System.out.println(response);
            System.out.println("--------------\n");
        }

        socket.close();
        sc.close();
    }
}
