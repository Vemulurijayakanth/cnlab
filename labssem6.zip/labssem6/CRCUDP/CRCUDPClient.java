import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class CRCUDPClient {
    public static void main(String[] args) {
        try (DatagramSocket clientSocket = new DatagramSocket(); Scanner sc = new Scanner(System.in)) {
            InetAddress serverIP = InetAddress.getByName("localhost");
            System.out.println("CRC UDP Client is ready...");

            while (true) {
                System.out.print("Enter binary message (or 'quit' to exit): ");
                String message = sc.nextLine();

                String toSend;
                if (message.equalsIgnoreCase("quit")) {
                    toSend = "quit";
                } else {
                    toSend = CRCUtil.encode(message);
                    System.out.println("Sending Codeword: " + toSend);
                }

                byte[] sendBytes = toSend.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, serverIP, 9876);
                clientSocket.send(sendPacket);

                if (message.equalsIgnoreCase("quit")) {
                    System.out.println("Client exiting...");
                    break;
                }

                byte[] buffer = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                clientSocket.receive(receivePacket);

                String serverReply = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Server Reply: " + serverReply);
            }

        } catch (Exception e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}
