import java.io.*;
import java.net.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class TCPServer {
    private static AtomicInteger clientCount = new AtomicInteger(0);
    private static ConcurrentHashMap<Integer, ClientHandler> activeClients = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        int port = 12345;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                int clientId = clientCount.incrementAndGet();
                System.out.println("New client connected: " + clientId);

                ClientHandler clientHandler = new ClientHandler(clientSocket, clientId);
                activeClients.put(clientId, clientHandler);

                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            System.out.println("Error starting server: " + e.getMessage());
        }
    }

    public static void removeClient(int clientId) {
        activeClients.remove(clientId);
        System.out.println("Client " + clientId + " disconnected");

        if (activeClients.isEmpty()) {
            System.out.println("No active clients. Shutting down server...");
            System.exit(0);
        }
    }
}

class ClientHandler implements Runnable {
    private Socket socket;
    private int clientId;

    public ClientHandler(Socket socket, int clientId) {
        this.socket = socket;
        this.clientId = clientId;
    }

    @Override
    public void run() {
        try (
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true)
        ) {
            output.println("Hello, Client " + clientId);

            String message;
            while ((message = input.readLine()) != null) {
                System.out.println("Client " + clientId + " says: " + message);
                output.println("Server received: " + message);
            }
        } catch (IOException e) {
            System.out.println("Error communicating with client " + clientId);
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.out.println("Error closing socket for client " + clientId);
            }
            TCPServer.removeClient(clientId);
        }
    }
}
