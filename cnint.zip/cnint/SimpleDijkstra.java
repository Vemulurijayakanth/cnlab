import java.util.Scanner;

public class SimpleDijkstra {

    private static final int INF = Integer.MAX_VALUE;  // Using Integer.MAX_VALUE as infinity

    private void dijkstra(int[][] graph, int source) {
        int n = graph.length;
        int[] dist = new int[n];
        boolean[] visited = new boolean[n];

        // Initialize distances
        for (int i = 0; i < n; i++) dist[i] = INF;
        dist[source] = 0;

        // Perform Dijkstra's algorithm
        for (int i = 0; i < n - 1; i++) {
            int u = findMin(dist, visited);
            if (u == -1) break;
            visited[u] = true;

            for (int v = 0; v < n; v++) {
                if (!visited[v] && graph[u][v] != INF && dist[u] != INF && dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v];
                }
            }
        }

        // Output the shortest distances
        System.out.println("Vertex\tDistance");
        for (int i = 0; i < n; i++) {
            System.out.println(i + "\t" + (dist[i] == INF ? "INF" : dist[i]));
        }
    }

    private int findMin(int[] dist, boolean[] visited) {
        int min = INF, minIndex = -1;
        for (int i = 0; i < dist.length; i++) {
            if (!visited[i] && dist[i] < min) {
                min = dist[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Input number of nodes
            System.out.println("Enter the number of nodes:");
            int n = scanner.nextInt();
            if (n <= 0) {
                System.out.println("Number of nodes must be greater than zero.");
                return;
            }

            int[][] graph = new int[n][n];

            // Input adjacency matrix
            System.out.println("Enter the adjacency matrix (use " + INF + " for no edge):");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    graph[i][j] = scanner.nextInt();
                }
            }

            // Input source node
            System.out.println("Enter the source node:");
            int source = scanner.nextInt();
            if (source < 0 || source >= n) {
                System.out.println("Invalid source node.");
                return;
            }

            // Run Dijkstra's algorithm
            new SimpleDijkstra().dijkstra(graph, source);

        } catch (Exception e) {
            System.out.println("Invalid input, please enter valid integers.");
        } finally {
            scanner.close();
        }
    }
}
