import java.util.Scanner;

class TrieNode {
    TrieNode[] children = new TrieNode[26]; // 26 letters for English alphabet
    boolean isEndOfWord = false;

    // Constructor to initialize a node
    public TrieNode() {
        for (int i = 0; i < 26; i++) {
            children[i] = null;
        }
    }
}

class Trie {
    private TrieNode root;

    // Constructor to initialize the Trie
    public Trie() {
        root = new TrieNode();
    }

    // Method to insert a word into the Trie
    public void insert(String word) {
        TrieNode node = root;
        for (int i = 0; i < word.length(); i++) {
            char ch = word.charAt(i);
            int index = ch - 'a'; // Calculate index for character 'a' to 'z'
            if (node.children[index] == null) {
                node.children[index] = new TrieNode();
            }
            node = node.children[index];
        }
        node.isEndOfWord = true;
    }

    // Method to find the longest common prefix
    public String longestCommonPrefix() {
        TrieNode node = root;
        StringBuilder prefix = new StringBuilder();

        // Traverse the Trie to find the longest common prefix
        while (node != null && countChildren(node) == 1 && !node.isEndOfWord) {
            for (int i = 0; i < 26; i++) {
                if (node.children[i] != null) {
                    prefix.append((char) (i + 'a'));
                    node = node.children[i];
                    break;
                }
            }
        }

        return prefix.toString();
    }

    // Helper method to count the number of children of a node
    private int countChildren(TrieNode node) {
        int count = 0;
        for (int i = 0; i < 26; i++) {
            if (node.children[i] != null) {
                count++;
            }
        }
        return count;
    }
}

public class LongestCommonPrefix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Trie trie = new Trie();

        // Taking dynamic input
        System.out.print("Enter the number of words: ");
        int numWords = scanner.nextInt();
        scanner.nextLine();  // consume the newline character

        System.out.println("Enter the words:");
        for (int i = 0; i < numWords; i++) {
            String word = scanner.nextLine().trim();
            trie.insert(word);
        }

        // Finding the longest common prefix
        String lcp = trie.longestCommonPrefix();
        System.out.println("The longest common prefix is: " + lcp);

        scanner.close();
    }
}
