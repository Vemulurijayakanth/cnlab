import java.util.Scanner;

class LeakyBucket {
    private double capacity;
    private double currentWater;
    private double fillRate;
    private double leakRate;

    public LeakyBucket(double capacity, double fillRate, double leakRate) {
        this.capacity = capacity;
        this.fillRate = fillRate;
        this.leakRate = leakRate;
        this.currentWater = 0;
    }

    public void simulate(int seconds) {
        for (int i = 1; i <= seconds; i++) {
            currentWater += fillRate;
            currentWater -= leakRate;

            if (currentWater < 0) currentWater = 0;

            if (currentWater > capacity) {
                System.out.println("Overflow! Wasting " + (currentWater - capacity) + " units.");
                currentWater = capacity;
            }

            System.out.println("Time: " + i + "s | Current Volume: " + currentWater + " units");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter bucket capacity: ");
        double capacity = sc.nextDouble();
        System.out.print("Enter water inflow rate: ");
        double fillRate = sc.nextDouble();
        System.out.print("Enter water leak rate: ");
        double leakRate = sc.nextDouble();
        System.out.print("Enter simulation duration (seconds): ");
        int duration = sc.nextInt();

        LeakyBucket bucket = new LeakyBucket(capacity, fillRate, leakRate);
        bucket.simulate(duration);

        sc.close();
    }
}
