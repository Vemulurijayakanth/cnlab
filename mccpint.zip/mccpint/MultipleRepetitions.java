import java.util.Scanner;

public class MultipleRepetitions {

    // Function to find the first occurrence of the element using binary search
    public static int firstOccurrence(int[] arr, int target) {
        int low = 0, high = arr.length - 1;
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) {
                result = mid;
                high = mid - 1; // Keep searching in the left half
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return result;
    }

    // Function to find the last occurrence of the element using binary search
    public static int lastOccurrence(int[] arr, int target) {
        int low = 0, high = arr.length - 1;
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) {
                result = mid;
                low = mid + 1; // Keep searching in the right half
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return result;
    }

    // Function to find the number of occurrences of the element in the array
    public static int countOccurrences(int[] arr, int target) {
        int first = firstOccurrence(arr, target);
        if (first == -1) {
            return 0; // Element is not found
        }

        int last = lastOccurrence(arr, target);

        return last - first + 1; // The number of occurrences
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input the sorted array and the target element
        System.out.print("Enter the number of elements in the array: ");
        int n = sc.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array (sorted):");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.print("Enter the element to find its repetitions: ");
        int target = sc.nextInt();

        // Calculate and print the number of repetitions
        int result = countOccurrences(arr, target);
        System.out.println("The element " + target + " is repeated " + result + " times.");

        sc.close();
    }
}
