import java.util.Scanner;

class Node {
    int data;
    Node next;

    // Constructor to create a new node
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    // Insert node at the end
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Delete nth node from the end of the list
    public void deleteNthFromEnd(int n) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node first = head;
        Node second = head;

        // Move first pointer n nodes ahead
        for (int i = 0; i < n; i++) {
            if (first == null) {
                System.out.println("n is greater than the length of the list.");
                return;
            }
            first = first.next;
        }

        // If first pointer is null, it means we need to delete the head node
        if (first == null) {
            head = head.next;
            return;
        }

        // Move both pointers one step at a time until the first pointer reaches the end
        while (first.next != null) {
            first = first.next;
            second = second.next;
        }

        // Delete the node
        second.next = second.next.next;
    }

    // Display the linked list
    public void display() {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node temp = head;
        System.out.print("Linked List: ");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class LinkedListDeleteNthFromEnd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList list = new LinkedList();
        
        System.out.print("Enter number of elements in the linked list: ");
        int n = sc.nextInt();
        
        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            list.insert(data);
        }

        // Display the linked list
        list.display();

        System.out.print("Enter the position from the end to delete: ");
        int position = sc.nextInt();

        // Delete nth node from the end
        list.deleteNthFromEnd(position);

        // Display the modified linked list
        list.display();

        sc.close();
    }
}
