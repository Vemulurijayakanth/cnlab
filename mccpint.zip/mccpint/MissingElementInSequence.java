import java.util.Scanner;

public class MissingElementInSequence {

    // Function to find the missing element in the sequence
    public static int findMissingElement(int[] arr) {
        int n = arr.length;
        int diff = (arr[n - 1] - arr[0]) / (n);  // Calculate the common difference

        // Traverse through the array to find where the difference is not equal to 'diff'
        for (int i = 0; i < n - 1; i++) {
            if (arr[i + 1] - arr[i] != diff) {
                return arr[i] + diff; // The missing element
            }
        }
        return -1; // If no missing element is found
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Take dynamic input for the sequence
        System.out.print("Enter the number of elements in the sequence: ");
        int n = sc.nextInt();
        int[] arr = new int[n];

        System.out.println("Enter the elements of the sequence:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        // Find the missing element
        int missingElement = findMissingElement(arr);
        System.out.println("The missing element is: " + missingElement);

        sc.close();
    }
}
