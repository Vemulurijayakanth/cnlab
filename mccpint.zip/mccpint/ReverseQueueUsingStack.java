import java.io.*;

public class ReverseQueueUsingStack {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter number of elements in the queue: ");
        int n = Integer.parseInt(br.readLine());

        int[] queue = new int[n];
        int top = -1;
        int[] stack = new int[n];

        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            queue[i] = Integer.parseInt(br.readLine());
        }

        System.out.print("Original Queue: ");
        for (int i = 0; i < n; i++) {
            System.out.print(queue[i] + " ");
        }

        // Enqueue to stack (reverse)
        for (int i = 0; i < n; i++) {
            stack[++top] = queue[i];
        }

        // Dequeue from stack back to queue
        for (int i = 0; i < n; i++) {
            queue[i] = stack[top--];
        }

        System.out.print("\nReversed Queue: ");
        for (int i = 0; i < n; i++) {
            System.out.print(queue[i] + " ");
        }

        System.out.println();
    }
}
