import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ByteStuffingClient {
    private static final String FLAG = "01111110";
    private static final String ESCAPE = "01111101";

    public static void main(String[] args) {
        String serverIP = "127.0.0.1";
        int port = 5000;

        try (Socket socket = new Socket(serverIP, port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter binary data (multiple of 8 bits): ");
            String input = scanner.nextLine();

            String stuffed = stuffData(input);
            System.out.println("Stuffed Data Sent: " + stuffed);

            out.println(stuffed);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String stuffData(String data) {
        StringBuilder stuffedData = new StringBuilder(FLAG);
        for (int i = 0; i < data.length(); i += 8) {
            String byteChunk = data.substring(i, Math.min(i + 8, data.length()));
            if (byteChunk.equals(FLAG) || byteChunk.equals(ESCAPE)) {
                stuffedData.append(ESCAPE);
            }
            stuffedData.append(byteChunk);
        }
        stuffedData.append(FLAG);
        return stuffedData.toString();
    }
}
