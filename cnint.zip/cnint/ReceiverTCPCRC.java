import java.io.*;
import java.net.*;

public class ReceiverTCPCRC {
    public static void main(String[] args) throws Exception {
        String g = "100000111";

        ServerSocket server = new ServerSocket(9876);
        System.out.println("Receiver is waiting for data...");

        Socket socket = server.accept();
        DataInputStream dis = new DataInputStream(socket.getInputStream());

        String rData = dis.readUTF();
        System.out.println("Received data: " + rData);

        boolean isValid = checkCRC(rData, g);
        if (isValid) {
            System.out.println("No errors in received data.");
        } else {
            System.out.println("Errors detected in received data.");
        }

        dis.close();
        socket.close();
        server.close();
    }

    private static boolean checkCRC(String data, String g) {
        int dl = data.length();
        int gl = g.length();
        char[] dArr = data.toCharArray();
        char[] gArr = g.toCharArray();

        for (int i = 0; i <= dl - gl; i++) {
            if (dArr[i] == '1') {
                for (int j = 0; j < gl; j++) {
                    dArr[i + j] = (dArr[i + j] == gArr[j]) ? '0' : '1';
                }
            }
        }

        for (int i = dl - gl + 1; i < dl; i++) {
            if (dArr[i] != '0') return false;
        }
        return true;
    }
}
