import java.util.Scanner;

class BST {
    static class Node {
        int data;
        Node left, right;
        Node(int value) {
            data = value;
            left = right = null;
        }
    }

    Node root;

    Node insert(Node node, int data) {
        if (node == null) return new Node(data);
        if (data < node.data) node.left = insert(node.left, data);
        else node.right = insert(node.right, data);
        return node;
    }

    void printLeftNodes(Node node) {
        if (node == null) return;
        if (node.left != null) {
            System.out.print(node.left.data + " ");
            printLeftNodes(node.left);
        }
        printLeftNodes(node.right);
    }

    public static void main(String[] args) {
        BST tree = new BST();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of nodes:");
        int n = scanner.nextInt();

        System.out.println("Enter BST values:");
        for (int i = 0; i < n; i++) {
            tree.root = tree.insert(tree.root, scanner.nextInt());
        }

        System.out.println("Left Nodes:");
        tree.printLeftNodes(tree.root);
    }
}
