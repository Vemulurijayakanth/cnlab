import java.util.Scanner;
import java.util.Stack;

public class StackWithMin {
    private Stack<Integer> stack;
    private Stack<Integer> minStack;

    public StackWithMin() {
        stack = new Stack<>();
        minStack = new Stack<>();
    }

    // Function to push an element onto the stack
    public void push(int value) {
        stack.push(value);
        
        // If minStack is empty or value is smaller than the top of minStack, push it to minStack
        if (minStack.isEmpty() || value <= minStack.peek()) {
            minStack.push(value);
        } else {
            minStack.push(minStack.peek()); // Push the current minimum again
        }
    }

    // Function to pop an element from the stack
    public int pop() {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }
        minStack.pop();
        return stack.pop();
    }

    // Function to get the minimum element
    public int getMin() {
        if (minStack.isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }
        return minStack.peek(); // The top of minStack will always be the minimum element
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StackWithMin stackWithMin = new StackWithMin();

        // Dynamic input for stack elements
        System.out.print("Enter the number of elements in the stack: ");
        int n = sc.nextInt();

        System.out.println("Enter the elements to push onto the stack:");
        for (int i = 0; i < n; i++) {
            int value = sc.nextInt();
            stackWithMin.push(value);
        }

        // Get the minimum element in the stack
        System.out.println("The minimum element in the stack is: " + stackWithMin.getMin());

        sc.close();
    }
}
