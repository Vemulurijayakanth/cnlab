import java.util.Scanner;

public class RotatedSortedArraySearch {

    // Function to search the target in a rotated sorted array
    public static int search(int[] arr, int target) {
        int start = 0, end = arr.length - 1;

        while (start <= end) {
            int mid = start + (end - start) / 2;

            if (arr[mid] == target) {
                return mid; // target found
            }

            // Check if left part is sorted
            if (arr[start] <= arr[mid]) {
                if (target >= arr[start] && target < arr[mid]) {
                    end = mid - 1; // Search in left half
                } else {
                    start = mid + 1; // Search in right half
                }
            }
            // Right part is sorted
            else {
                if (target > arr[mid] && target <= arr[end]) {
                    start = mid + 1; // Search in right half
                } else {
                    end = mid - 1; // Search in left half
                }
            }
        }
        return -1; // target not found
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the number of elements in the rotated sorted array: ");
        int n = sc.nextInt();

        // Input array elements
        int[] arr = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        // Input target value
        System.out.print("Enter the target value to search: ");
        int target = sc.nextInt();

        // Perform the search
        int index = search(arr, target);

        // Output result
        if (index != -1) {
            System.out.println("Target found at index: " + index);
        } else {
            System.out.println("Target not found.");
        }

        sc.close();
    }
}
