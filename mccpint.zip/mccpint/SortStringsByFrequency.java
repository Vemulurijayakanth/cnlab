import java.util.*;

public class SortStringsByFrequency {
    
    public static String[] sortByFrequency(String[] arr) {
        // Count the frequency of each string
        HashMap<String, Integer> freqMap = new HashMap<>();
        for (String str : arr) {
            // Use containsKey to check the frequency, and update manually
            if (freqMap.containsKey(str)) {
                freqMap.put(str, freqMap.get(str) + 1);
            } else {
                freqMap.put(str, 1);
            }
        }
        
        // Sort the strings based on frequency, then lexicographically
        final HashMap<String, Integer> finalFreqMap = freqMap;  // Make freqMap final
        Arrays.sort(arr, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                int freqA = finalFreqMap.get(a);
                int freqB = finalFreqMap.get(b);
                
                // First compare by frequency
                if (freqA != freqB) {
                    return freqA - freqB;
                }
                // If frequencies are the same, compare lexicographically
                return a.compareTo(b);
            }
        });
        
        return arr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the number of strings: ");
        int n = sc.nextInt();
        sc.nextLine();  // consume newline
        
        String[] arr = new String[n];
        System.out.println("Enter the strings:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextLine();
        }
        
        String[] sortedArr = sortByFrequency(arr);
        System.out.println("The sorted array of strings is:");
        System.out.println(Arrays.toString(sortedArr));
        
        sc.close();
    }
}
