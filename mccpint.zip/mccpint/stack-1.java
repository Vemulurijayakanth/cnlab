import java.util.*;

public class Main {
    public static void reverseStack(Stack<Integer> stack) {
        Queue<Integer> queue = new LinkedList<>();
        while (!stack.isEmpty()) queue.add(stack.pop());
        while (!queue.isEmpty()) stack.push(queue.remove());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < n; i++) stack.push(sc.nextInt());
        reverseStack(stack);
        while (!stack.isEmpty()) System.out.print(stack.pop() + " ");
    }
}
