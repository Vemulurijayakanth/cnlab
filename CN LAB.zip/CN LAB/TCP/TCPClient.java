import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) {
        String serverIP = "127.0.0.1"; // localhost
        int port = 12345;

        try (
            Socket socket = new Socket(serverIP, port);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println(input.readLine()); // Welcome from server

            String message;
            while (true) {
                System.out.print("Message: ");
                message = consoleInput.readLine();
                if (message.equalsIgnoreCase("exit")) {
                    System.out.println("Disconnecting...");
                    break;
                }

                output.println(message);
                System.out.println("Server: " + input.readLine());
            }
        } catch (IOException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
    }
}
