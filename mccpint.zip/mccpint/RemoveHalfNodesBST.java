import java.util.*;

class TreeNode {
    int val;
    TreeNode left, right;
    TreeNode(int val) { this.val = val; }
}

public class RemoveHalfNodesBST {
    public static TreeNode removeHalfNodes(TreeNode root) {
        if (root == null) return null;

        root.left = removeHalfNodes(root.left);
        root.right = removeHalfNodes(root.right);

        if (root.left == null && root.right == null) return root;
        if (root.left == null) return root.right;
        if (root.right == null) return root.left;

        return root;
    }

    public static TreeNode insert(TreeNode root, int val) {
        if (root == null) return new TreeNode(val);
        if (val < root.val) root.left = insert(root.left, val);
        else root.right = insert(root.right, val);
        return root;
    }

    public static void inorder(TreeNode root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.val + " ");
            inorder(root.right);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TreeNode root = null;
        System.out.print("Enter number of nodes in BST: ");
        int n = sc.nextInt();

        System.out.println("Enter node values:");
        for (int i = 0; i < n; i++) {
            int val = sc.nextInt();
            root = insert(root, val);
        }

        System.out.print("Inorder before removing half nodes: ");
        inorder(root);
        root = removeHalfNodes(root);
        System.out.print("\nInorder after removing half nodes: ");
        inorder(root);
    }
}
