import java.util.Scanner;

class Node {
    int data;
    Node next;

    // Constructor to create a new node
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    // Insert node at the end
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Iterative search for an element and return its index
    public int searchIterative(int target) {
        Node temp = head;
        int index = 0;
        while (temp != null) {
            if (temp.data == target) {
                return index; // Return the index where the element is found
            }
            temp = temp.next;
            index++;
        }
        return -1; // Element not found
    }

    // Display the linked list
    public void display() {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node temp = head;
        System.out.print("Linked List: ");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class LinkedListIterativeSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList list = new LinkedList();
        
        System.out.print("Enter number of elements in the linked list: ");
        int n = sc.nextInt();
        
        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            list.insert(data);
        }

        // Display the linked list
        list.display();

        System.out.print("Enter value to search: ");
        int target = sc.nextInt();

        // Iterative search
        int index = list.searchIterative(target);
        if (index != -1) {
            System.out.println("Element " + target + " found at index " + index + " (Iterative search).");
        } else {
            System.out.println("Element " + target + " not found (Iterative search).");
        }

        sc.close();
    }
}
