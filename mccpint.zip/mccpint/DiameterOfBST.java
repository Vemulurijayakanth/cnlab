import java.util.*;

public class DiameterOfBST {
    static class Node {
        int data;
        Node left, right;
        Node(int val) {
            data = val;
            left = right = null;
        }
    }

    static class Tree {
        Node root;

        int maxDiameter = 0;

        int diameter(Node node) {
            if (node == null) return 0;

            int leftHeight = diameter(node.left);
            int rightHeight = diameter(node.right);

            maxDiameter = Math.max(maxDiameter, leftHeight + rightHeight + 1);
            return Math.max(leftHeight, rightHeight) + 1;
        }

        void insert(int data) {
            root = insertRec(root, data);
        }

        Node insertRec(Node root, int data) {
            if (root == null) {
                root = new Node(data);
                return root;
            }
            if (data < root.data) root.left = insertRec(root.left, data);
            else root.right = insertRec(root.right, data);
            return root;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Tree tree = new Tree();

        System.out.print("Enter number of nodes: ");
        int n = sc.nextInt();
        System.out.println("Enter node values:");
        for (int i = 0; i < n; i++) {
            tree.insert(sc.nextInt());
        }

        tree.diameter(tree.root);
        System.out.println("Diameter of BST: " + tree.maxDiameter);
    }
}
