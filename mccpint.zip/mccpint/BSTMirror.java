import java.util.*;

public class BSTMirror {
    
    // Node class to represent a tree node
    static class Node {
        int data;
        Node left, right;
        Node(int val) {
            data = val;
            left = right = null;
        }
    }
    
    // Function to insert a node in BST
    static Node insert(Node root, int data) {
        if (root == null) {
            return new Node(data);
        }
        
        if (data < root.data) {
            root.left = insert(root.left, data);
        } else {
            root.right = insert(root.right, data);
        }
        
        return root;
    }
    
    // Function to print inorder traversal of the tree
    static void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }
    
    // Function to generate the mirror of the tree
    static Node mirror(Node root) {
        if (root == null) return null;
        
        // Recursively mirror the left and right subtrees
        Node left = mirror(root.left);
        Node right = mirror(root.right);
        
        // Swap left and right children
        root.left = right;
        root.right = left;
        
        return root;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of nodes in the BST: ");
        int n = sc.nextInt();
        
        Node root = null;
        System.out.println("Enter the node values:");
        for (int i = 0; i < n; i++) {
            int value = sc.nextInt();
            root = insert(root, value);
        }
        
        System.out.print("Inorder traversal of BST: ");
        inorder(root);
        System.out.println();
        
        root = mirror(root);
        
        System.out.print("Inorder traversal of mirrored BST: ");
        inorder(root);
    }
}
