import java.util.*;

class JobSequencing {
    static ArrayList<Integer> jobSequencing(int[] deadline, int[] profit) {
        int n = deadline.length;
        int cnt = 0;
        int totProfit = 0;

        ArrayList<int[]> jobs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            jobs.add(new int[]{profit[i], deadline[i]});
        }

        jobs.sort((a, b) -> Integer.compare(b[0], a[0]));
        int[] slot = new int[n];

        for (int i = 0; i < n; i++) {
            int start = Math.min(n, jobs.get(i)[1]) - 1;
            for (int j = start; j >= 0; j--) {
                if (slot[j] == 0) {
                    slot[j] = 1;
                    cnt++;
                    totProfit += jobs.get(i)[0];
                    break;
                }
            }
        }

        ArrayList<Integer> result = new ArrayList<>();
        result.add(cnt);
        result.add(totProfit);
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of jobs: ");
        int n = sc.nextInt();

        int[] deadline = new int[n];
        int[] profit = new int[n];

        System.out.println("Enter deadlines:");
        for (int i = 0; i < n; i++) {
            deadline[i] = sc.nextInt();
        }

        System.out.println("Enter profits:");
        for (int i = 0; i < n; i++) {
            profit[i] = sc.nextInt();
        }

        ArrayList<Integer> ans = jobSequencing(deadline, profit);
        System.out.println(ans.get(0) + " " + ans.get(1));
    }
}