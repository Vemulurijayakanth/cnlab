import java.util.*;

public class RemoveDuplicates {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements in array: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter array elements:");
        for(int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        // TreeSet to remove duplicates and maintain sorted order
        Set<Integer> unique = new TreeSet<>();
        for(int num : arr) {
            unique.add(num);
        }

        System.out.println("Array after removing duplicates (sorted):");
        for(int num : unique) {
            System.out.print(num + " ");
        }

        sc.close();
    }
}
