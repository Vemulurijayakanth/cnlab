import java.net.*;
import java.util.Scanner;

public class BitStuffing_UDPSender {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the binary string:");
        String input = sc.nextLine();
        sc.close();

        String FLAG = "01111110";
        String stuffedData = FLAG + bitStuff(input) + FLAG;

        DatagramSocket socket = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        DatagramPacket packet = new DatagramPacket(stuffedData.getBytes(), stuffedData.length(), ip, 9877);
        socket.send(packet);
        System.out.println("Bit Stuffed Data with flag: " + stuffedData);
        socket.close();
    }

    public static String bitStuff(String data) {
        StringBuilder stuffed = new StringBuilder();
        int count = 0;
        for (int i = 0; i < data.length(); i++) {
            stuffed.append(data.charAt(i));
            if (data.charAt(i) == '1') {
                count++;
                if (count == 5) {
                    stuffed.append('0');
                    count = 0;
                }
            } else {
                count = 0;
            }
        }
        return stuffed.toString();
    }
}