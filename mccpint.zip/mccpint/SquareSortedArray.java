import java.util.Arrays;
import java.util.Scanner;

public class SquareSortedArray {

    // Method to square the elements and return the sorted array
    public static int[] squareAndSort(int[] arr) {
        int n = arr.length;
        int[] squaredArray = new int[n];

        // Squaring each element of the array
        for (int i = 0; i < n; i++) {
            squaredArray[i] = arr[i] * arr[i];
        }

        // Sorting the squared array
        Arrays.sort(squaredArray);
        return squaredArray;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking dynamic input for the array
        System.out.println("Enter the number of elements in the array:");
        int n = scanner.nextInt();
        
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array (in sorted order):");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Squaring and sorting the array
        int[] result = squareAndSort(arr);

        // Displaying the squared and sorted array
        System.out.println("Squared and sorted array:");
        System.out.println(Arrays.toString(result));

        scanner.close();
    }
}
