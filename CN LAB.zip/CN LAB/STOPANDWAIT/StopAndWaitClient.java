import java.io.*;
import java.net.*;
import java.util.Scanner;
public class StopAndWaitClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 5000);
        System.out.println("Connected to server.");
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        Scanner scanner = new Scanner(System.in);
        int frame = 0;
        while (true) {
            System.out.print("Send frame " + frame + "? (yes/exit): ");
            String input = scanner.nextLine();            
            if (input.equalsIgnoreCase("exit")) {
                out.println("exit");
                break;
            }           
            boolean ackReceived = false;
            while (!ackReceived) {
                out.println("Frame " + frame);
                System.out.println("Sent Frame: " + frame);                
                try {
                    socket.setSoTimeout(3000); // Set timeout for ACK
                    String ack = in.readLine();
                    if (ack != null && ack.contains("ACK")) {
                        System.out.println("Received: " + ack);
                        ackReceived = true;
                    }
                } catch (SocketTimeoutException e) {
                    System.out.println("ACK not received, resending Frame: " + frame);
                }
            }
            frame++;
        }        
        in.close();
        out.close();
        socket.close();
        scanner.close();
    }
}
