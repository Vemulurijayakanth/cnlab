import java.net.*;

public class BitUnStuffing_UDPReceiver {
    public static void main(String[] args) throws Exception {
        String FLAG = "01111110";
        DatagramSocket socket = new DatagramSocket(9877);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        System.out.println("Waiting for stuffed data...");
        socket.receive(packet);
        String received = new String(packet.getData(), 0, packet.getLength());
        String unstuffedData = removeFlags(received, FLAG);
        unstuffedData = bitUnstuff(unstuffedData);
        System.out.println("Original data: " + unstuffedData);
        socket.close();
    }

    public static String removeFlags(String data, String FLAG) {
        if (data.startsWith(FLAG) && data.endsWith(FLAG)) {
            return data.substring(FLAG.length(), data.length() - FLAG.length());
        } else {
            System.out.println("Error: Missing flags!");
            return "";
        }
    }

    public static String bitUnstuff(String data) {
        return data.replace("111110", "11111");
    }
}