import java.util.*;

public class Main {
    public static void deleteMiddle(Stack<Integer> stack, int current, int size) {
        if (stack.isEmpty() || current == size / 2) {
            stack.pop();
            return;
        }
        int temp = stack.pop();
        deleteMiddle(stack, current + 1, size);
        stack.push(temp);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < n; i++) stack.push(sc.nextInt());
        deleteMiddle(stack, 0, n);
        while (!stack.isEmpty()) System.out.print(stack.pop() + " ");
    }
}
