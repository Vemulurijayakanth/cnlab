import java.util.Scanner;

public class MinOperationsToConvertArrays {
    
    // Method to calculate the minimum operations required
    public static int minOperations(int[] arr1, int[] arr2) {
        int operations = 0;
        
        // Loop through both arrays and sum up the absolute differences
        for (int i = 0; i < arr1.length; i++) {
            operations += Math.abs(arr1[i] - arr2[i]);  // Absolute difference between arr1 and arr2
        }
        
        return operations;  // Return the total number of operations
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read the size of arrays
        System.out.print("Enter the number of elements in the arrays: ");
        int n = sc.nextInt();  // Size of the arrays
        
        // Declare and read elements for the first array
        int[] arr1 = new int[n];
        System.out.println("Enter elements for the first array:");
        for (int i = 0; i < n; i++) {
            arr1[i] = sc.nextInt();
        }

        // Declare and read elements for the second array
        int[] arr2 = new int[n];
        System.out.println("Enter elements for the second array:");
        for (int i = 0; i < n; i++) {
            arr2[i] = sc.nextInt();
        }

        // Calculate minimum operations to convert arr1 to arr2
        int result = minOperations(arr1, arr2);

        // Print the result
        System.out.println("Minimum number of operations to convert arr1 to arr2: " + result);
    }
}
