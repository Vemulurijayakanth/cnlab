import java.net.*;
import java.util.Scanner;

public class ByteStuffing_UDPSender {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String flag = "01111110";
        String esc = "01111101";
        System.out.println("Enter the input:");
        String input = sc.nextLine();
        StringBuilder td = new StringBuilder();
        td.append(flag);
        for (int i = 0; i < input.length(); i += 8) {
            String b8 = input.substring(i, Math.min(i + 8, input.length()));
            if (b8.equals(flag) || b8.equals(esc)) {
                td.append(esc);
            }
            td.append(b8);
        }
        td.append(flag);
        String stuffedData = td.toString();

        DatagramSocket socket = new DatagramSocket();
        InetAddress ip = InetAddress.getByName("localhost");
        DatagramPacket packet = new DatagramPacket(stuffedData.getBytes(), stuffedData.length(), ip, 9878);
        socket.send(packet);
        System.out.println("Transmitted: " + stuffedData);
        socket.close();
        sc.close();
    }
}