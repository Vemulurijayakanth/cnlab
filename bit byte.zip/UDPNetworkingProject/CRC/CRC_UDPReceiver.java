import java.net.*;

public class CRC_UDPReceiver {
    public static void main(String[] args) throws Exception {
        String g = "100000111";
        DatagramSocket socket = new DatagramSocket(9876);
        byte[] receiveData = new byte[1024];
        DatagramPacket packet = new DatagramPacket(receiveData, receiveData.length);
        System.out.println("Waiting for data...");
        socket.receive(packet);
        String rData = new String(packet.getData(), 0, packet.getLength());
        boolean isValid = checkCRC(rData, g);
        if (isValid) {
            System.out.println("No errors in received data.");
        } else {
            System.out.println("Errors detected in received data.");
        }
        socket.close();
    }

    private static boolean checkCRC(String data, String g) {
        int dl = data.length();
        int gl = g.length();
        char[] dArr = data.toCharArray();
        char[] gArr = g.toCharArray();
        for (int i = 0; i <= dl - gl; i++) {
            if (dArr[i] == '1') {
                for (int j = 0; j < gl; j++) {
                    dArr[i + j] = (dArr[i + j] == gArr[j]) ? '0' : '1';
                }
            }
        }
        for (int i = dl - gl + 1; i < dl; i++) {
            if (dArr[i] != '0') return false;
        }
        return true;
    }
}