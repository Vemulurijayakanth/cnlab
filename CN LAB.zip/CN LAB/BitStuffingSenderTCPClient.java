import java.io.*;
import java.net.*;
import java.util.Scanner;

public class BitStuffingSenderTCPClient {
    public static void main(String[] args) {
        String serverIP = "127.0.0.1";
        int port = 12345;
        try (
            Socket socket = new Socket(serverIP, port);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner scanner = new Scanner(System.in)
        ) {
            System.out.print("Enter input bit sequence: ");
            String rawInput = scanner.nextLine();
            String stuffedBits = stuffBits(rawInput);
            System.out.println("Stuffed Bit Sequence: " + stuffedBits);
            output.println(stuffedBits);  
            String response = input.readLine();  
            System.out.println("Server (Destuffed): " + response);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    private static String stuffBits(String input) {
        StringBuilder output = new StringBuilder("01111110");
        int count = 0;
        for (char bit : input.toCharArray()) {
            output.append(bit);
            if (bit == '1') {
                count++;
                if (count == 5) {
                    output.append('0');
                    count = 0;
                }
            } else {
                count = 0;
            }
        }
        output.append("01111110");
        return output.toString();
    }
}
