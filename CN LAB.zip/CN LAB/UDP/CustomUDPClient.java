import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;
public class CustomUDPClient {
    public static void main(String[] args) {
        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress serverIP = InetAddress.getByName("localhost");
            Scanner userInput = new Scanner(System.in);
            System.out.println("Custom UDP Client is active...");
            while (true) {
                System.out.print("Type your message (or 'quit' to exit): ");
                String userMessage = userInput.nextLine();
                byte[] sendData = userMessage.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverIP, 9876);
                clientSocket.send(sendPacket);
                if (userMessage.equalsIgnoreCase("quit")) {
                    System.out.println("Exiting client...");
                    break;
                }
                byte[] buffer = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                clientSocket.receive(receivePacket);

                String serverReply = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Server replied: " + serverReply);
            }
        } catch (Exception e) {
            System.err.println("An error occurred in the client: " + e.getMessage());
        }
    }
}
