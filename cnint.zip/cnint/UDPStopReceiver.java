import java.net.*;
import java.util.Random;

public class UDPStopReceiver {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket(9876);
        byte[] receiveBuffer = new byte[1024];
        byte[] sendBuffer;

        Random rand = new Random();

        System.out.println("Receiver started...");

        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
            socket.receive(receivePacket);

            String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength());
            int frameNum = Integer.parseInt(receivedData.trim());
            System.out.println("Received Frame: " + frameNum);

            // Simulate ACK loss randomly
            boolean sendAck = rand.nextBoolean();
            if (sendAck) {
                String ack = "ACK" + frameNum;
                sendBuffer = ack.getBytes();

                InetAddress senderAddress = receivePacket.getAddress();
                int senderPort = receivePacket.getPort();

                DatagramPacket ackPacket = new DatagramPacket(sendBuffer, sendBuffer.length, senderAddress, senderPort);
                socket.send(ackPacket);
                System.out.println("Sent: " + ack);
            } else {
                System.out.println("Simulating lost ACK for Frame: " + frameNum);
            }
        }
    }
}
