import java.io.*;
import java.net.*;
import java.util.Random;
public class StopAndWaitServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(5000);
        System.out.println("Server is waiting for connection...");
        Socket socket = serverSocket.accept();
        System.out.println("Client connected.");
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        Random random = new Random();
        int frame = 0;
        while (true) {
            String received = in.readLine();
            if (received.equals("exit")) {
                System.out.println("Client has exited.");
                break;
            }
            System.out.println("Received: " + received);
                if (random.nextInt(10) < 3) {
                System.out.println("ACK lost or delayed for Frame: " + frame);
                continue; 
            }
            
            out.println("ACK " + frame);
            System.out.println("Sent ACK: " + frame);
            frame++;
        }
        in.close();
        out.close();
        socket.close();
        serverSocket.close();
    }
}
