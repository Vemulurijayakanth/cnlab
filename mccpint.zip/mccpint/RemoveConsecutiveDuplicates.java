import java.util.Scanner;

public class RemoveConsecutiveDuplicates {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        StringBuilder result = new StringBuilder();
        char prev = 0;

        for (int i = 0; i < input.length(); i++) {
            char current = input.charAt(i);
            if (current != prev) {
                result.append(current);
                prev = current;
            }
        }

        System.out.println("Result after removing consecutive duplicates: " + result.toString());
    }
}
