import java.io.*;
import java.net.*;

public class TCPServerCRC {
    private static final String GENERATOR = "100000111";

    public static void main(String[] args) {
        int port = 12345;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port " + port);
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected!");

            BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true);

            output.println("Welcome to the CRC Server!");

            String codeword = input.readLine();
            System.out.println("Received codeword: " + codeword);

            boolean isValid = checkForErrors(codeword);
            if (isValid) {
                output.println("No error detected.");
            } else {
                output.println("Error detected in transmission.");
            }

            clientSocket.close();
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    private static boolean checkForErrors(String codeword) {
        char[] bits = codeword.toCharArray();
        int generatorLength = GENERATOR.length();
        int dataLength = bits.length;

        for (int i = 0; i <= dataLength - generatorLength; i++) {
            if (bits[i] == '1') {
                for (int j = 0; j < generatorLength; j++) {
                    if (bits[i + j] == GENERATOR.charAt(j)) {
                        bits[i + j] = '0';
                    } else {
                        bits[i + j] = '1';
                    }
                }
            }
        }

        for (int i = dataLength - generatorLength + 1; i < dataLength; i++) {
            if (bits[i] == '1') {
                return false;
            }
        }
        return true;
    }
}
