import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s1 = sc.next();
        String s2 = sc.next();
        int len1 = s1.length();
        int len2 = s2.length();
        int i = 0;

        while (i < len1 || i < len2) {
            if (i < len1) System.out.print(s1.charAt(i));
            if (i < len2) System.out.print(s2.charAt(i));
            i++;
        }
    }
}
